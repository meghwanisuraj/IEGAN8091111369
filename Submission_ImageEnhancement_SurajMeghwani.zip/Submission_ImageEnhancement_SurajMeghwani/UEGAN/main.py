# USAGE
# python main.py --mode test --version UEGAN-FiveK --pretrained_model 92 --inputpdfs input_pdf

import os
import cv2
import argparse
from trainer import Trainer
from tester import Tester
from utils import create_folder, setup_seed
from config import get_config
from Preprocessing.ImagePreprocessor import ImagePreprocessor
from MyMetrics.Metrics import BrisqueMetric
from glob import glob
import torch
from munch import Munch
from data_loader import get_train_loader, get_test_loader

def main(args):

    # create directories if not exist.
    create_folder(args.save_root_dir, args.version, args.model_save_path)
    create_folder(args.save_root_dir, args.version, args.test_result_path)

    ip = ImagePreprocesor()

    # Path to images in Pdf format
    imagePaths = glob(os.path.join(args.inputpdfs,"*.{}".format('pdf')))
    ip.convert2PNG(imagePaths, args.test_img_dir)
    imagePaths = glob(os.path.join(args.test_img_dir,"raw", "*.{}".format('png')))
    ip.preprocess(imagePaths)

    # for fast training.
    torch.backends.cudnn.benchmark = True
    setup_seed(args.seed)


    if args.mode == 'test':
        loaders = Munch(tes=get_test_loader(root=args.test_img_dir,
                                            img_size=args.test_img_size,
                                            batch_size=args.val_batch_size,
                                            shuffle=True,
                                            num_workers=args.num_workers))
        tester = Tester(loaders, args)
        tester.test()
    else:
        raise NotImplementedError('Mode [{}] is not found'.format(args.mode))


    # Compution of input images Brisque Score

    imagePaths = glob(os.path.join(args.test_img_dir+os.path.sep+"raw","*.{}".format('png')))
    inpM = BrisqueMetric()
    inpM.computeScore(imagePaths)
    for key in inpM.score:
        print("{} : {}".format(key, inpM.score[key]))

    #outputImagepaths = os.path.sep.join([args.test_result_path, "test_results"])
    imagePaths = glob(os.path.join(args.test_out_path,"*.{}".format('png')))
    outM = BrisqueMetric()
    outM.computeScore(imagePaths)
    for key in outM.score:
        print("{} : {}".format(key, outM.score[key]))


if __name__ == '__main__':

    args = get_config()
    main(args)
