# import the necessary packages
import numpy as np
import cv2
import os
import fitz

class ImagePreprocessor:
    def __init__(self, width=512, height=512, inter= cv2.INTER_AREA, preprocessors=None):
        self.preprocessors = preprocessors
        self.width = width
        self.height= height
        self.inter = inter

    # Just for resizing of the image
    def preprocess(self, imagePaths):
		# resize the image to a fixed size, ignoring the aspect ratio
        for (i, imagePath) in enumerate(imagePaths):
            image = cv2.imread(imagePath)
            image = cv2.resize(image,(self.width, self.height), interpolation=self.inter)
            cv2.imwrite(imagePath, image)

    # Conversion of pdf to png
    def convert2PNG(self, sourceimgPaths, destimgPath):
        """Convert all images in sourceimgPath to PNG format and [optionally] copies
        all converted images in the in the specified destimgPath folder"""
        for (i, imagePath) in enumerate(sourceimgPaths):
            #Convert the image from pdf to PNG
            pdf = fitz.open(imagePath)
            a_page = pdf.loadPage(0)
            pixMap = a_page.getPixmap()
            imagename = imagePath.split(os.path.sep)[-1]
            imagename = imagename.split('.')[-2]+'.png'
            #pixMap.writePNG(destimgPath+os.path.sep+"label"+os.path.sep+imagename)
            pixMap.writePNG(destimgPath+os.path.sep+"raw"+os.path.sep+imagename)
