Unsupervised Image Enhancement Generative Adversarial Network 
UEGAN

Requirements and Installations 

>Python 3.6
>PyTorch 1.4.0
tqdm 4.43.0
munch 2.5.0
torchvision 0.5.0
glob
fitz
numpy
skimage
cv2

Some implementation points for UEGAN:

1. All given input images (in pdf format) are converted into .png file (lossless compression) using fitz module.
2. Only No-Reference Metrics is considered for Image quality assessment using BRISQUE (Refer MyMetrics/Metrics.py) 
3. Images are converted into pngs and copied in /data/fivek/test/raw/ folder where the algorithm fetches the images (all is handled in the main.py file)
4. Input pdf images can be found in input_pdf folder.
5.  After testing output images can be found in ./results/UEGAN-FiveK/test/test_results/ and comparative images can be found in generated in ./results/UEGAN-FiveK/test/test_compare/


Usage: (testing the code)

python main.py --mode test --version UEGAN-FiveK --pretrained_model 92 --inputpdfs input_pdf

--mode : Only test mode is enabled as pre-trained model is used.
--version : For creating folders
--pretrained_model 92 pre-trained model present in the folder ./results/UEGAN-FiveK/models/
--inputpdfs : Name of the folder which contains pdf input images 


