import os.path
import numpy as np
from skimage import img_as_float
from skimage.io import imread
import imquality.brisque as brisque
import PIL.Image

class BrisqueMetric:
    def __init__(self):
        self.score = {}
        self.score2={}

    def computeScore(self, imagepaths):
        """Function to compute the measure of quality of unparied images"""
        for (i, imagePath) in enumerate(imagepaths):
            targetImage = imread(imagePath, as_gray=False)
            targetImage2 = PIL.Image.open(imagePath)
            img_as_float(targetImage)

            self.score[imagePath.split(os.path.sep)[-1]] = brisque.score(targetImage)
            self.score2[imagePath.split(os.path.sep)[-1]] = brisque.score(targetImage2)



